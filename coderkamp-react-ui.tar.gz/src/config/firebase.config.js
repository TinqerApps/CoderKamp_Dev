export default  {
    apiKey: 'AIzaSyA5G3dbdvXl4OigYAKRSlUkGdVU6e6W8Sw',
    authDomain: 'ace-firepad.firebaseapp.com',
    databaseURL: 'https://ace-firepad.firebaseio.com',
    projectId: 'ace-firepad',
    storageBucket: 'ace-firepad.appspot.com',
    messagingSenderId: '746723152682'
  };